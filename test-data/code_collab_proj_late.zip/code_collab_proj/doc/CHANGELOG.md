# Changelog
## v2
- Added config
