# Early version
print('hello')
