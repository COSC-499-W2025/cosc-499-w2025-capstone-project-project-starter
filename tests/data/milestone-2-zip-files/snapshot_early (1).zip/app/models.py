"""Domain models for the task manager."""
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import List, Optional
import uuid


class Priority(Enum):
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"


class Status(Enum):
    TODO = "todo"
    IN_PROGRESS = "in_progress"
    DONE = "done"
    CANCELLED = "cancelled"


@dataclass
class Tag:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    color: str = "#cccccc"

    def __post_init__(self):
        self.name = self.name.strip().lower()


@dataclass
class Comment:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    author: str = ""
    body: str = ""
    created_at: datetime = field(default_factory=datetime.utcnow)


@dataclass
class Task:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    title: str = ""
    description: str = ""
    priority: Priority = Priority.NORMAL
    status: Status = Status.TODO
    tags: List[Tag] = field(default_factory=list)
    comments: List[Comment] = field(default_factory=list)
    due_date: Optional[datetime] = None
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)

    def complete(self):
        self.status = Status.DONE
        self.updated_at = datetime.utcnow()

    def cancel(self):
        self.status = Status.CANCELLED
        self.updated_at = datetime.utcnow()

    def start(self):
        self.status = Status.IN_PROGRESS
        self.updated_at = datetime.utcnow()

    def add_tag(self, tag: Tag):
        if not any(t.name == tag.name for t in self.tags):
            self.tags.append(tag)
            self.updated_at = datetime.utcnow()

    def add_comment(self, author: str, body: str) -> Comment:
        c = Comment(author=author, body=body)
        self.comments.append(c)
        self.updated_at = datetime.utcnow()
        return c

    def is_overdue(self) -> bool:
        if self.due_date is None:
            return False
        return datetime.utcnow() > self.due_date and self.status not in (
            Status.DONE, Status.CANCELLED
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "priority": self.priority.value,
            "status": self.status.value,
            "tags": [{"id": t.id, "name": t.name, "color": t.color} for t in self.tags],
            "comments": [
                {"id": c.id, "author": c.author, "body": c.body,
                 "created_at": c.created_at.isoformat()}
                for c in self.comments
            ],
            "due_date": self.due_date.isoformat() if self.due_date else None,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Task":
        t = cls(
            id=data["id"],
            title=data["title"],
            description=data.get("description", ""),
            priority=Priority(data.get("priority", "normal")),
            status=Status(data.get("status", "todo")),
        )
        if data.get("due_date"):
            t.due_date = datetime.fromisoformat(data["due_date"])
        t.created_at = datetime.fromisoformat(data["created_at"])
        t.updated_at = datetime.fromisoformat(data["updated_at"])
        t.tags = [Tag(**tag) for tag in data.get("tags", [])]
        t.comments = [
            Comment(
                id=c["id"], author=c["author"], body=c["body"],
                created_at=datetime.fromisoformat(c["created_at"])
            )
            for c in data.get("comments", [])
        ]
        return t
