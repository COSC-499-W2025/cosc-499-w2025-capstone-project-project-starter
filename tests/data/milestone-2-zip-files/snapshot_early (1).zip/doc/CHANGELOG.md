# Changelog

## v0.1.0 — 2024-01-10
- Initial release
- Basic Task model with status and priority
- JSON storage backend
- CLI: add, list, complete, delete

## v0.2.0 — 2024-01-28
- Add tag support
- Add comment system
- Add filtering utilities
- Improve CLI output formatting
