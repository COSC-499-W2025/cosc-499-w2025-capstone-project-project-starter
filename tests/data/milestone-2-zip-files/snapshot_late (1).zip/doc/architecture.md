# Architecture

## Overview

The Task Manager follows a layered architecture:

```
cli.py          ← user interaction
  ↓
models.py       ← domain objects (Task, Tag, Comment)
  ↓
storage.py      ← persistence (JsonStorage)
  ↓
filters.py      ← query/sort helpers
stats.py        ← aggregations
export.py       ← serialisation
backup.py       ← backup/restore
config.py       ← environment config
```

## Storage

Tasks are stored in `data/tasks.json` as a JSON array.
Atomic writes via a `.tmp` file + rename prevent corruption.

## Design Decisions

- **Dataclasses** for models: clear, minimal boilerplate.
- **No external DB**: simplicity is a feature for a CLI tool.
- **Enums** for status/priority: prevents invalid states.
