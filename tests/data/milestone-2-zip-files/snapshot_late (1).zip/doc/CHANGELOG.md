# Changelog

## v0.1.0 — 2024-01-10
- Initial release

## v0.2.0 — 2024-01-28
- Add tag support, comments, filtering

## v0.3.0 — 2024-02-10
- Backup and restore
- CSV, JSON, Markdown export
- Statistics module

## v0.4.0 — 2024-03-01
- Recurring tasks
- Due-date notifications
- File-based sync utilities
- Expanded test coverage
