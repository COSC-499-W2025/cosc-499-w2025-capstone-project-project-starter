# Task Manager

A full-featured command-line task management application written in Python.

## Features

- Create, list, complete, and delete tasks
- Priority levels: low, normal, high, critical
- Tag-based organisation
- Due dates with overdue detection
- Comments on tasks
- JSON-based persistent storage with atomic writes
- Backup and restore
- CSV, JSON, and Markdown export
- Rich filtering and sorting

## Installation

```bash
pip install -r requirements.txt
```

## Quick Start

```bash
python -m app.cli add "Buy groceries" --priority high --due 2024-03-01 --tags personal,errands
python -m app.cli list --status todo --verbose
python -m app.cli complete <task-id>
python -m app.cli delete <task-id>
```

## Development

```bash
pip install -r requirements-dev.txt
pytest
```
