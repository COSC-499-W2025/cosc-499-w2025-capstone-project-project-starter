from setuptools import find_packages, setup

setup(
    name="task-manager",
    version="0.1.0",
    packages=find_packages(),
    entry_points={"console_scripts": ["tasks=app.cli:main"]},
    python_requires=">=3.9",
)
