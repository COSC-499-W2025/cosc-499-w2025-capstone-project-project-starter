"""Command-line interface for the task manager."""
import argparse
import sys
from datetime import datetime
from typing import Optional
from app.models import Priority, Status, Tag, Task
from app.storage import JsonStorage
from app.filters import by_status, by_priority, search, sort_by_priority


storage = JsonStorage()


def _print_task(task: Task, verbose: bool = False):
    status_icon = {"todo": "○", "in_progress": "◑", "done": "●", "cancelled": "✗"}
    icon = status_icon.get(task.status.value, "?")
    tags = " ".join(f"[{t.name}]" for t in task.tags)
    print(f"  {icon} {task.id[:8]}  {task.title}  {tags}")
    if verbose:
        if task.description:
            print(f"     {task.description}")
        print(f"     Priority: {task.priority.value}  Status: {task.status.value}")
        if task.due_date:
            print(f"     Due: {task.due_date.date()}")
        for c in task.comments:
            print(f"     [{c.author}] {c.body}")


def cmd_add(args):
    task = Task(
        title=args.title,
        description=args.description or "",
        priority=Priority(args.priority),
    )
    if args.due:
        task.due_date = datetime.strptime(args.due, "%Y-%m-%d")
    if args.tags:
        for name in args.tags.split(","):
            task.add_tag(Tag(name=name.strip()))
    storage.upsert(task)
    print(f"Created task {task.id[:8]}: {task.title}")


def cmd_list(args):
    tasks = storage.load_all()
    if args.status:
        tasks = by_status(tasks, Status(args.status))
    if args.priority:
        tasks = by_priority(tasks, Priority(args.priority))
    if args.search:
        tasks = search(tasks, args.search)
    tasks = sort_by_priority(tasks)
    print(f"Tasks ({len(tasks)}):")
    for t in tasks:
        _print_task(t, verbose=args.verbose)


def cmd_complete(args):
    task = storage.get(args.id)
    if not task:
        print(f"Task not found: {args.id}", file=sys.stderr)
        sys.exit(1)
    task.complete()
    storage.upsert(task)
    print(f"Completed: {task.title}")


def cmd_delete(args):
    if storage.delete(args.id):
        print(f"Deleted task {args.id}")
    else:
        print(f"Task not found: {args.id}", file=sys.stderr)
        sys.exit(1)


def cmd_comment(args):
    task = storage.get(args.id)
    if not task:
        print(f"Task not found: {args.id}", file=sys.stderr)
        sys.exit(1)
    task.add_comment(args.author, args.body)
    storage.upsert(task)
    print(f"Comment added to {task.title}")


def build_parser():
    parser = argparse.ArgumentParser(prog="tasks", description="Task Manager CLI")
    sub = parser.add_subparsers(dest="command")

    p_add = sub.add_parser("add", help="Create a new task")
    p_add.add_argument("title")
    p_add.add_argument("-d", "--description", default="")
    p_add.add_argument("-p", "--priority", default="normal",
                       choices=["low", "normal", "high", "critical"])
    p_add.add_argument("--due", help="Due date YYYY-MM-DD")
    p_add.add_argument("--tags", help="Comma-separated tags")
    p_add.set_defaults(func=cmd_add)

    p_list = sub.add_parser("list", help="List tasks")
    p_list.add_argument("-s", "--status")
    p_list.add_argument("-p", "--priority")
    p_list.add_argument("--search")
    p_list.add_argument("-v", "--verbose", action="store_true")
    p_list.set_defaults(func=cmd_list)

    p_done = sub.add_parser("complete", help="Mark task complete")
    p_done.add_argument("id")
    p_done.set_defaults(func=cmd_complete)

    p_del = sub.add_parser("delete", help="Delete a task")
    p_del.add_argument("id")
    p_del.set_defaults(func=cmd_delete)

    p_comment = sub.add_parser("comment", help="Add a comment to a task")
    p_comment.add_argument("id")
    p_comment.add_argument("--author", required=True)
    p_comment.add_argument("--body", required=True)
    p_comment.set_defaults(func=cmd_comment)

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(0)
    args.func(args)


if __name__ == "__main__":
    main()
