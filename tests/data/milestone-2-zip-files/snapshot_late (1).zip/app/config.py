"""Application configuration."""
import os
from dataclasses import dataclass


@dataclass
class Config:
    data_dir: str = "data"
    log_level: str = "INFO"
    max_tasks: int = 10000
    backup_enabled: bool = True
    backup_dir: str = "backups"
    date_format: str = "%Y-%m-%d"

    @classmethod
    def from_env(cls) -> "Config":
        return cls(
            data_dir=os.environ.get("TASKS_DATA_DIR", "data"),
            log_level=os.environ.get("TASKS_LOG_LEVEL", "INFO"),
            max_tasks=int(os.environ.get("TASKS_MAX", "10000")),
            backup_enabled=os.environ.get("TASKS_BACKUP", "true").lower() == "true",
            backup_dir=os.environ.get("TASKS_BACKUP_DIR", "backups"),
        )
