"""Notification system for due date reminders."""
from datetime import datetime, timedelta
from typing import Callable, List, Optional
from app.models import Task


NotifyFn = Callable[[str, str], None]


def console_notify(subject: str, body: str):
    print(f"[NOTIFY] {subject}: {body}")


def check_due_soon(tasks: List[Task], days_ahead: int = 1,
                   notify_fn: NotifyFn = console_notify):
    cutoff = datetime.utcnow() + timedelta(days=days_ahead)
    triggered = []
    for t in tasks:
        if t.due_date and t.due_date <= cutoff and not t.status.value in ("done", "cancelled"):
            notify_fn(
                f"Task due soon: {t.title}",
                f"Due: {t.due_date.date()}  Priority: {t.priority.value}"
            )
            triggered.append(t)
    return triggered


def check_overdue(tasks: List[Task], notify_fn: NotifyFn = console_notify):
    triggered = []
    for t in tasks:
        if t.is_overdue():
            notify_fn(
                f"OVERDUE: {t.title}",
                f"Was due: {t.due_date.date()}"
            )
            triggered.append(t)
    return triggered
