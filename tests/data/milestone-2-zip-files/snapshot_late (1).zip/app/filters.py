"""Filtering and sorting utilities for tasks."""
from datetime import datetime
from typing import Callable, List, Optional
from app.models import Priority, Status, Task


def by_status(tasks: List[Task], status: Status) -> List[Task]:
    return [t for t in tasks if t.status == status]


def by_priority(tasks: List[Task], priority: Priority) -> List[Task]:
    return [t for t in tasks if t.priority == priority]


def by_tag(tasks: List[Task], tag_name: str) -> List[Task]:
    name = tag_name.strip().lower()
    return [t for t in tasks if any(tg.name == name for tg in t.tags)]


def overdue(tasks: List[Task]) -> List[Task]:
    return [t for t in tasks if t.is_overdue()]


def search(tasks: List[Task], query: str) -> List[Task]:
    q = query.lower()
    return [
        t for t in tasks
        if q in t.title.lower() or q in t.description.lower()
    ]


def sort_by_priority(tasks: List[Task], descending: bool = True) -> List[Task]:
    order = {Priority.CRITICAL: 4, Priority.HIGH: 3,
             Priority.NORMAL: 2, Priority.LOW: 1}
    return sorted(tasks, key=lambda t: order[t.priority], reverse=descending)


def sort_by_due_date(tasks: List[Task]) -> List[Task]:
    no_due = [t for t in tasks if t.due_date is None]
    with_due = [t for t in tasks if t.due_date is not None]
    return sorted(with_due, key=lambda t: t.due_date) + no_due


def sort_by_created(tasks: List[Task], descending: bool = True) -> List[Task]:
    return sorted(tasks, key=lambda t: t.created_at, reverse=descending)


def compose(*fns: Callable[[List[Task]], List[Task]]) -> Callable:
    def apply(tasks):
        for fn in fns:
            tasks = fn(tasks)
        return tasks
    return apply
