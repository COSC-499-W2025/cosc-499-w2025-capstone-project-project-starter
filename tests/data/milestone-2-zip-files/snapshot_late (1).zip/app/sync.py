"""Simple file-based sync utilities for sharing tasks across machines."""
import hashlib
import json
from pathlib import Path
from typing import List, Tuple
from app.models import Task
from app.storage import JsonStorage


def compute_checksum(tasks: List[Task]) -> str:
    raw = json.dumps([t.to_dict() for t in sorted(tasks, key=lambda t: t.id)],
                     sort_keys=True)
    return hashlib.sha256(raw.encode()).hexdigest()


def diff_tasks(local: List[Task], remote: List[Task]) -> Tuple[List[Task], List[Task], List[str]]:
    local_map = {t.id: t for t in local}
    remote_map = {t.id: t for t in remote}
    added = [t for tid, t in remote_map.items() if tid not in local_map]
    updated = [
        t for tid, t in remote_map.items()
        if tid in local_map and t.updated_at > local_map[tid].updated_at
    ]
    deleted = [tid for tid in local_map if tid not in remote_map]
    return added, updated, deleted


def merge(local: List[Task], remote: List[Task]) -> List[Task]:
    added, updated, deleted = diff_tasks(local, remote)
    local_map = {t.id: t for t in local}
    for t in added:
        local_map[t.id] = t
    for t in updated:
        local_map[t.id] = t
    for tid in deleted:
        local_map.pop(tid, None)
    return list(local_map.values())
