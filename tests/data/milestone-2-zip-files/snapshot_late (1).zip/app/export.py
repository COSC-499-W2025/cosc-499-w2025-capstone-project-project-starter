"""Export tasks to various formats."""
import csv
import io
import json
from typing import List
from app.models import Task


def to_json(tasks: List[Task], indent: int = 2) -> str:
    return json.dumps([t.to_dict() for t in tasks], indent=indent)


def to_csv(tasks: List[Task]) -> str:
    buf = io.StringIO()
    fields = ["id", "title", "description", "priority", "status", "due_date",
              "created_at", "updated_at"]
    writer = csv.DictWriter(buf, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for t in tasks:
        row = t.to_dict()
        row["due_date"] = row.get("due_date") or ""
        writer.writerow({k: row.get(k, "") for k in fields})
    return buf.getvalue()


def to_markdown(tasks: List[Task]) -> str:
    lines = ["# Task Export
"]
    for t in tasks:
        check = "x" if t.status.value == "done" else " "
        lines.append(f"- [{check}] **{t.title}** `{t.priority.value}`")
        if t.description:
            lines.append(f"  > {t.description}")
        if t.due_date:
            lines.append(f"  Due: {t.due_date.date()}")
    return "
".join(lines)
