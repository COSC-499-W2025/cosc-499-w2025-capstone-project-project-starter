"""Persistent storage backend using JSON files."""
import json
import os
import shutil
from pathlib import Path
from typing import Dict, List, Optional
from app.models import Task


class StorageError(Exception):
    pass


class JsonStorage:
    def __init__(self, data_dir: str = "data"):
        self.data_dir = Path(data_dir)
        self.tasks_file = self.data_dir / "tasks.json"
        self._ensure_dir()

    def _ensure_dir(self):
        self.data_dir.mkdir(parents=True, exist_ok=True)
        if not self.tasks_file.exists():
            self.tasks_file.write_text("[]")

    def _read_raw(self) -> List[dict]:
        try:
            return json.loads(self.tasks_file.read_text())
        except (json.JSONDecodeError, OSError) as e:
            raise StorageError(f"Failed to read tasks: {e}") from e

    def _write_raw(self, data: List[dict]):
        tmp = self.tasks_file.with_suffix(".tmp")
        try:
            tmp.write_text(json.dumps(data, indent=2))
            shutil.move(str(tmp), str(self.tasks_file))
        except OSError as e:
            raise StorageError(f"Failed to write tasks: {e}") from e

    def load_all(self) -> List[Task]:
        return [Task.from_dict(d) for d in self._read_raw()]

    def save_all(self, tasks: List[Task]):
        self._write_raw([t.to_dict() for t in tasks])

    def get(self, task_id: str) -> Optional[Task]:
        for d in self._read_raw():
            if d["id"] == task_id:
                return Task.from_dict(d)
        return None

    def upsert(self, task: Task):
        data = self._read_raw()
        for i, d in enumerate(data):
            if d["id"] == task.id:
                data[i] = task.to_dict()
                self._write_raw(data)
                return
        data.append(task.to_dict())
        self._write_raw(data)

    def delete(self, task_id: str) -> bool:
        data = self._read_raw()
        filtered = [d for d in data if d["id"] != task_id]
        if len(filtered) == len(data):
            return False
        self._write_raw(filtered)
        return True

    def count(self) -> int:
        return len(self._read_raw())
