"""Backup and restore utilities."""
import json
import shutil
from datetime import datetime
from pathlib import Path
from typing import List
from app.models import Task
from app.storage import JsonStorage


def create_backup(storage: JsonStorage, backup_dir: str = "backups") -> Path:
    backup_path = Path(backup_dir)
    backup_path.mkdir(parents=True, exist_ok=True)
    ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    dest = backup_path / f"tasks_backup_{ts}.json"
    shutil.copy2(str(storage.tasks_file), str(dest))
    return dest


def restore_backup(backup_file: str, storage: JsonStorage):
    src = Path(backup_file)
    if not src.exists():
        raise FileNotFoundError(f"Backup file not found: {backup_file}")
    data = json.loads(src.read_text())
    tasks = [Task.from_dict(d) for d in data]
    storage.save_all(tasks)
    return len(tasks)


def list_backups(backup_dir: str = "backups") -> List[Path]:
    p = Path(backup_dir)
    if not p.exists():
        return []
    return sorted(p.glob("tasks_backup_*.json"), reverse=True)
