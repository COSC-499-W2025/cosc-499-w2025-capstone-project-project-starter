"""Statistics and reporting utilities."""
from collections import Counter
from typing import Dict, List
from app.models import Priority, Status, Task


def status_counts(tasks: List[Task]) -> Dict[str, int]:
    return dict(Counter(t.status.value for t in tasks))


def priority_counts(tasks: List[Task]) -> Dict[str, int]:
    return dict(Counter(t.priority.value for t in tasks))


def completion_rate(tasks: List[Task]) -> float:
    if not tasks:
        return 0.0
    done = sum(1 for t in tasks if t.status == Status.DONE)
    return round(done / len(tasks) * 100, 2)


def overdue_count(tasks: List[Task]) -> int:
    return sum(1 for t in tasks if t.is_overdue())


def top_tags(tasks: List[Task], n: int = 10) -> List[tuple]:
    counter: Counter = Counter()
    for t in tasks:
        for tag in t.tags:
            counter[tag.name] += 1
    return counter.most_common(n)


def avg_comments_per_task(tasks: List[Task]) -> float:
    if not tasks:
        return 0.0
    return round(sum(len(t.comments) for t in tasks) / len(tasks), 2)


def summary_report(tasks: List[Task]) -> dict:
    return {
        "total": len(tasks),
        "by_status": status_counts(tasks),
        "by_priority": priority_counts(tasks),
        "completion_rate_pct": completion_rate(tasks),
        "overdue": overdue_count(tasks),
        "top_tags": top_tags(tasks),
        "avg_comments": avg_comments_per_task(tasks),
    }
