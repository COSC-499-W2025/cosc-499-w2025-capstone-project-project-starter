"""Recurring task support."""
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Optional
from app.models import Priority, Task


class RecurrenceFreq(Enum):
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"


@dataclass
class RecurringTask:
    base_title: str
    freq: RecurrenceFreq
    priority: Priority = Priority.NORMAL
    last_generated: Optional[datetime] = None

    def next_due(self) -> datetime:
        base = self.last_generated or datetime.utcnow()
        if self.freq == RecurrenceFreq.DAILY:
            return base + timedelta(days=1)
        if self.freq == RecurrenceFreq.WEEKLY:
            return base + timedelta(weeks=1)
        # monthly approximation
        return base + timedelta(days=30)

    def generate(self) -> Task:
        due = self.next_due()
        t = Task(
            title=f"{self.base_title} ({due.strftime('%b %d')})",
            priority=self.priority,
            due_date=due,
        )
        self.last_generated = due
        return t
