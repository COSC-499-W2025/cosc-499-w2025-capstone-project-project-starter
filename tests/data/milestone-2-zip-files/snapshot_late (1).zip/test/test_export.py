"""Tests for export module."""
import csv
import io
import json
from app.export import to_csv, to_json, to_markdown
from app.models import Priority, Status, Tag, Task


def make_task(**kwargs):
    t = Task(title="Export me", **kwargs)
    return t


class TestExport:
    def test_to_json_valid(self):
        tasks = [make_task(), make_task(priority=Priority.HIGH)]
        result = json.loads(to_json(tasks))
        assert len(result) == 2
        assert result[0]["title"] == "Export me"

    def test_to_csv_headers(self):
        tasks = [make_task()]
        reader = csv.DictReader(io.StringIO(to_csv(tasks)))
        row = next(reader)
        assert "title" in row
        assert "priority" in row
        assert "status" in row

    def test_to_markdown_done(self):
        t = make_task()
        t.complete()
        md = to_markdown([t])
        assert "[x]" in md

    def test_to_markdown_todo(self):
        t = make_task()
        md = to_markdown([t])
        assert "[ ]" in md
