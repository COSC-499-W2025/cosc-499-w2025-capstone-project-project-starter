"""Tests for recurring task generation."""
from app.models import Priority
from app.recurrence import RecurrenceFreq, RecurringTask


def test_daily_recurrence():
    rt = RecurringTask(base_title="Daily standup", freq=RecurrenceFreq.DAILY)
    t1 = rt.generate()
    t2 = rt.generate()
    assert (t2.due_date - t1.due_date).days == 1


def test_weekly_recurrence():
    rt = RecurringTask(base_title="Weekly review", freq=RecurrenceFreq.WEEKLY)
    t1 = rt.generate()
    t2 = rt.generate()
    assert (t2.due_date - t1.due_date).days == 7


def test_generated_task_has_title():
    rt = RecurringTask(base_title="Report", freq=RecurrenceFreq.MONTHLY)
    t = rt.generate()
    assert "Report" in t.title
