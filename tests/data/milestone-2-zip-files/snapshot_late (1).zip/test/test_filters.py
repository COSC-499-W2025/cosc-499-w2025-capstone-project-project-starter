"""Tests for filter utilities."""
import pytest
from datetime import datetime, timedelta
from app.filters import (by_priority, by_status, by_tag, overdue,
                          search, sort_by_due_date, sort_by_priority)
from app.models import Priority, Status, Tag, Task


def make_task(title="t", status=Status.TODO, priority=Priority.NORMAL, **kwargs):
    return Task(title=title, status=status, priority=priority, **kwargs)


class TestFilters:
    def test_by_status(self):
        tasks = [make_task(status=Status.DONE), make_task(status=Status.TODO)]
        assert len(by_status(tasks, Status.DONE)) == 1

    def test_by_priority(self):
        tasks = [make_task(priority=Priority.HIGH), make_task(priority=Priority.LOW)]
        assert len(by_priority(tasks, Priority.HIGH)) == 1

    def test_by_tag(self):
        t = make_task()
        t.add_tag(Tag(name="work"))
        tasks = [t, make_task()]
        assert len(by_tag(tasks, "work")) == 1

    def test_overdue(self):
        past = make_task(due_date=datetime.utcnow() - timedelta(days=1))
        future = make_task(due_date=datetime.utcnow() + timedelta(days=1))
        assert len(overdue([past, future])) == 1

    def test_search_title(self):
        tasks = [make_task("Buy milk"), make_task("Write tests")]
        assert len(search(tasks, "milk")) == 1

    def test_search_description(self):
        t = make_task()
        t.description = "important thing"
        assert len(search([t], "important")) == 1

    def test_sort_by_priority(self):
        tasks = [
            make_task(priority=Priority.LOW),
            make_task(priority=Priority.CRITICAL),
            make_task(priority=Priority.NORMAL),
        ]
        sorted_tasks = sort_by_priority(tasks)
        assert sorted_tasks[0].priority == Priority.CRITICAL

    def test_sort_by_due_date(self):
        t1 = make_task(due_date=datetime.utcnow() + timedelta(days=5))
        t2 = make_task(due_date=datetime.utcnow() + timedelta(days=1))
        t3 = make_task()  # no due date
        result = sort_by_due_date([t1, t2, t3])
        assert result[0].due_date < result[1].due_date
        assert result[-1].due_date is None
