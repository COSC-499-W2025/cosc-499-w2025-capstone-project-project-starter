"""Tests for backup module."""
import json
import pytest
from app.backup import create_backup, list_backups, restore_backup
from app.models import Task
from app.storage import JsonStorage


@pytest.fixture
def storage(tmp_path):
    s = JsonStorage(data_dir=str(tmp_path / "data"))
    for i in range(3):
        s.upsert(Task(title=f"Task {i}"))
    return s


def test_create_backup(storage, tmp_path):
    backup_file = create_backup(storage, backup_dir=str(tmp_path / "backups"))
    assert backup_file.exists()
    data = json.loads(backup_file.read_text())
    assert len(data) == 3


def test_restore_backup(storage, tmp_path):
    backup_file = create_backup(storage, backup_dir=str(tmp_path / "backups"))
    new_storage = JsonStorage(data_dir=str(tmp_path / "new_data"))
    count = restore_backup(str(backup_file), new_storage)
    assert count == 3
    assert new_storage.count() == 3


def test_list_backups(storage, tmp_path):
    backup_dir = str(tmp_path / "backups")
    create_backup(storage, backup_dir=backup_dir)
    create_backup(storage, backup_dir=backup_dir)
    backups = list_backups(backup_dir=backup_dir)
    assert len(backups) == 2


def test_restore_missing_file(storage):
    with pytest.raises(FileNotFoundError):
        restore_backup("nonexistent.json", storage)
