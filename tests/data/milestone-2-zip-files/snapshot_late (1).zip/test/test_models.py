"""Tests for domain models."""
import pytest
from datetime import datetime, timedelta
from app.models import Comment, Priority, Status, Tag, Task


def make_task(**kwargs):
    defaults = {"title": "Test task"}
    defaults.update(kwargs)
    return Task(**defaults)


class TestTask:
    def test_creation_defaults(self):
        t = make_task()
        assert t.status == Status.TODO
        assert t.priority == Priority.NORMAL
        assert t.tags == []
        assert t.comments == []

    def test_complete(self):
        t = make_task()
        t.complete()
        assert t.status == Status.DONE

    def test_cancel(self):
        t = make_task()
        t.cancel()
        assert t.status == Status.CANCELLED

    def test_start(self):
        t = make_task()
        t.start()
        assert t.status == Status.IN_PROGRESS

    def test_add_tag(self):
        t = make_task()
        tag = Tag(name="urgent")
        t.add_tag(tag)
        assert len(t.tags) == 1
        assert t.tags[0].name == "urgent"

    def test_add_duplicate_tag(self):
        t = make_task()
        t.add_tag(Tag(name="urgent"))
        t.add_tag(Tag(name="urgent"))
        assert len(t.tags) == 1

    def test_add_comment(self):
        t = make_task()
        c = t.add_comment("alice", "Looks good")
        assert len(t.comments) == 1
        assert c.author == "alice"
        assert c.body == "Looks good"

    def test_is_overdue_no_due_date(self):
        t = make_task()
        assert not t.is_overdue()

    def test_is_overdue_past(self):
        t = make_task(due_date=datetime.utcnow() - timedelta(days=1))
        assert t.is_overdue()

    def test_is_overdue_future(self):
        t = make_task(due_date=datetime.utcnow() + timedelta(days=1))
        assert not t.is_overdue()

    def test_is_overdue_done(self):
        t = make_task(due_date=datetime.utcnow() - timedelta(days=1))
        t.complete()
        assert not t.is_overdue()

    def test_to_dict_roundtrip(self):
        t = make_task(title="Round trip", priority=Priority.HIGH)
        t.add_tag(Tag(name="test"))
        t.add_comment("bob", "hello")
        d = t.to_dict()
        t2 = Task.from_dict(d)
        assert t2.title == t.title
        assert t2.priority == t.priority
        assert len(t2.tags) == 1
        assert len(t2.comments) == 1


class TestTag:
    def test_name_normalized(self):
        tag = Tag(name="  Urgent  ")
        assert tag.name == "urgent"
