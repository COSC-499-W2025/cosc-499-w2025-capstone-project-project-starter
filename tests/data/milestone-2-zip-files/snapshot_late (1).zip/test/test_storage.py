"""Tests for storage layer."""
import pytest
from pathlib import Path
from app.models import Priority, Status, Tag, Task
from app.storage import JsonStorage, StorageError


@pytest.fixture
def storage(tmp_path):
    return JsonStorage(data_dir=str(tmp_path / "data"))


def make_task(title="Test", **kwargs):
    return Task(title=title, **kwargs)


class TestJsonStorage:
    def test_empty_load(self, storage):
        assert storage.load_all() == []

    def test_upsert_and_get(self, storage):
        t = make_task("Buy milk")
        storage.upsert(t)
        fetched = storage.get(t.id)
        assert fetched is not None
        assert fetched.title == "Buy milk"

    def test_get_missing(self, storage):
        assert storage.get("nonexistent") is None

    def test_upsert_updates(self, storage):
        t = make_task("Original")
        storage.upsert(t)
        t.title = "Updated"
        storage.upsert(t)
        assert storage.get(t.id).title == "Updated"
        assert storage.count() == 1

    def test_delete(self, storage):
        t = make_task()
        storage.upsert(t)
        assert storage.delete(t.id) is True
        assert storage.get(t.id) is None

    def test_delete_missing(self, storage):
        assert storage.delete("no-such-id") is False

    def test_count(self, storage):
        for i in range(5):
            storage.upsert(make_task(f"Task {i}"))
        assert storage.count() == 5

    def test_save_and_load_all(self, storage):
        tasks = [make_task(f"Task {i}") for i in range(10)]
        storage.save_all(tasks)
        loaded = storage.load_all()
        assert len(loaded) == 10

    def test_priority_roundtrip(self, storage):
        t = make_task(priority=Priority.CRITICAL)
        storage.upsert(t)
        assert storage.get(t.id).priority == Priority.CRITICAL
