"""Tests for notification system."""
from datetime import datetime, timedelta
from app.models import Priority, Status, Task
from app.notifications import check_due_soon, check_overdue


def make_task(**kwargs):
    return Task(title="t", **kwargs)


def test_due_soon_triggers():
    messages = []
    t = make_task(due_date=datetime.utcnow() + timedelta(hours=6))
    result = check_due_soon([t], days_ahead=1,
                             notify_fn=lambda s, b: messages.append(s))
    assert len(result) == 1
    assert len(messages) == 1


def test_due_soon_skips_done():
    messages = []
    t = make_task(due_date=datetime.utcnow() + timedelta(hours=6),
                   status=Status.DONE)
    result = check_due_soon([t], days_ahead=1,
                             notify_fn=lambda s, b: messages.append(s))
    assert len(result) == 0


def test_overdue_triggers():
    messages = []
    t = make_task(due_date=datetime.utcnow() - timedelta(days=2))
    result = check_overdue([t], notify_fn=lambda s, b: messages.append(s))
    assert len(result) == 1
