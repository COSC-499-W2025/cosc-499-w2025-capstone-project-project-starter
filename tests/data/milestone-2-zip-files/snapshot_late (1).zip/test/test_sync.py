"""Tests for sync utilities."""
from datetime import datetime, timedelta
from app.models import Task
from app.sync import compute_checksum, diff_tasks, merge


def make_task(title="t", **kwargs):
    return Task(title=title, **kwargs)


def test_checksum_stable():
    tasks = [make_task("a"), make_task("b")]
    assert compute_checksum(tasks) == compute_checksum(tasks)


def test_diff_added():
    local = [make_task("a")]
    remote = [make_task("a"), make_task("b")]
    # give remote task a different id
    remote[0] = local[0]
    added, updated, deleted = diff_tasks(local, remote)
    assert len(added) == 1


def test_merge_incorporates_remote():
    local = [make_task("a")]
    new_task = make_task("b")
    merged = merge(local, local + [new_task])
    assert len(merged) == 2
