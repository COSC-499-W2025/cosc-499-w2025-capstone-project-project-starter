"""Tests for statistics module."""
from datetime import datetime, timedelta
from app.models import Priority, Status, Tag, Task
from app.stats import (avg_comments_per_task, completion_rate, overdue_count,
                        priority_counts, status_counts, summary_report, top_tags)


def make_task(**kwargs):
    return Task(title="t", **kwargs)


class TestStats:
    def test_status_counts(self):
        tasks = [
            make_task(status=Status.DONE),
            make_task(status=Status.DONE),
            make_task(status=Status.TODO),
        ]
        counts = status_counts(tasks)
        assert counts["done"] == 2
        assert counts["todo"] == 1

    def test_completion_rate(self):
        tasks = [make_task(status=Status.DONE), make_task(status=Status.TODO)]
        assert completion_rate(tasks) == 50.0

    def test_completion_rate_empty(self):
        assert completion_rate([]) == 0.0

    def test_overdue_count(self):
        past = make_task(due_date=datetime.utcnow() - timedelta(days=1))
        future = make_task(due_date=datetime.utcnow() + timedelta(days=1))
        assert overdue_count([past, future]) == 1

    def test_top_tags(self):
        t1 = make_task()
        t2 = make_task()
        t1.add_tag(Tag(name="work"))
        t2.add_tag(Tag(name="work"))
        t2.add_tag(Tag(name="personal"))
        result = dict(top_tags([t1, t2]))
        assert result["work"] == 2
        assert result["personal"] == 1

    def test_avg_comments(self):
        t1 = make_task()
        t1.add_comment("alice", "hi")
        t1.add_comment("bob", "hey")
        t2 = make_task()
        assert avg_comments_per_task([t1, t2]) == 1.0

    def test_summary_report_keys(self):
        report = summary_report([make_task()])
        assert "total" in report
        assert "by_status" in report
        assert "completion_rate_pct" in report
