"""Tests for transaction models."""
import pytest
from app.models import Category, Transaction, TransactionType


def make_tx(**kwargs):
    defaults = {"amount": 50.0, "type": TransactionType.EXPENSE,
                "category": Category.FOOD}
    defaults.update(kwargs)
    return Transaction(**defaults)


def test_creation():
    t = make_tx()
    assert t.amount == 50.0
    assert t.type == TransactionType.EXPENSE


def test_to_dict_roundtrip():
    t = make_tx(description="Lunch", tags=["work"])
    d = t.to_dict()
    t2 = Transaction.from_dict(d)
    assert t2.amount == t.amount
    assert t2.description == "Lunch"
    assert t2.tags == ["work"]


def test_from_dict_all_fields():
    d = {
        "id": "abc",
        "amount": 100.0,
        "type": "income",
        "category": "salary",
        "description": "Monthly pay",
        "date": "2024-02-01T10:00:00",
        "tags": ["regular"],
    }
    t = Transaction.from_dict(d)
    assert t.type == TransactionType.INCOME
    assert t.category == Category.SALARY
