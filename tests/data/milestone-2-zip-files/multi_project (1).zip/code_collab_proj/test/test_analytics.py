"""Tests for analytics module."""
from datetime import datetime
from app.analytics import (by_category, monthly_summary, net_balance,
                             over_budget, top_expense_categories, total_expenses,
                             total_income)
from app.models import Category, Transaction, TransactionType


def income(amount, cat=Category.SALARY):
    return Transaction(amount=amount, type=TransactionType.INCOME, category=cat)


def expense(amount, cat=Category.FOOD, **kwargs):
    return Transaction(amount=amount, type=TransactionType.EXPENSE,
                        category=cat, **kwargs)


def test_total_income():
    txs = [income(1000), expense(200)]
    assert total_income(txs) == 1000.0


def test_total_expenses():
    txs = [income(1000), expense(200), expense(50)]
    assert total_expenses(txs) == 250.0


def test_net_balance():
    txs = [income(1000), expense(400)]
    assert net_balance(txs) == 600.0


def test_by_category():
    txs = [expense(100, Category.FOOD), expense(50, Category.FOOD),
            expense(200, Category.TRANSPORT)]
    cats = by_category(txs)
    assert cats["food"] == 150.0
    assert cats["transport"] == 200.0


def test_over_budget():
    txs = [expense(200, Category.FOOD)]
    result = over_budget(txs, {"food": 100.0})
    assert result["food"] == 100.0


def test_top_expense_categories():
    txs = [expense(500, Category.HOUSING), expense(200, Category.FOOD),
            expense(100, Category.TRANSPORT)]
    top = top_expense_categories(txs, n=2)
    assert top[0][0] == "housing"
    assert len(top) == 2


def test_monthly_summary():
    t1 = Transaction(amount=1000, type=TransactionType.INCOME,
                      category=Category.SALARY,
                      date=datetime(2024, 2, 1))
    t2 = Transaction(amount=300, type=TransactionType.EXPENSE,
                      category=Category.FOOD,
                      date=datetime(2024, 2, 15))
    summary = monthly_summary([t1, t2])
    assert "2024-02" in summary
    assert summary["2024-02"]["net"] == 700.0
