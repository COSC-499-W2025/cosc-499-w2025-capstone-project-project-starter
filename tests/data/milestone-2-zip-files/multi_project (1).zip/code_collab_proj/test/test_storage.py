"""Tests for transaction storage."""
import pytest
from app.models import Category, Transaction, TransactionType
from app.storage import TransactionStore


@pytest.fixture
def store(tmp_path):
    return TransactionStore(path=str(tmp_path / "data/txs.json"))


def make_tx(**kwargs):
    return Transaction(amount=10.0, type=TransactionType.EXPENSE,
                        category=Category.FOOD, **kwargs)


def test_save_and_get(store):
    tx = make_tx(description="Coffee")
    store.save(tx)
    fetched = store.get(tx.id)
    assert fetched.description == "Coffee"


def test_get_missing(store):
    assert store.get("nope") is None


def test_delete(store):
    tx = make_tx()
    store.save(tx)
    assert store.delete(tx.id) is True
    assert store.get(tx.id) is None


def test_count(store):
    for _ in range(4):
        store.save(make_tx())
    assert store.count() == 4


def test_upsert(store):
    tx = make_tx()
    store.save(tx)
    tx.description = "Updated"
    store.save(tx)
    assert store.count() == 1
    assert store.get(tx.id).description == "Updated"
