"""Integration tests for REST API."""
import json
import pytest
from app.api import app as flask_app
from app.storage import TransactionStore


@pytest.fixture
def client(tmp_path, monkeypatch):
    import app.api as api_module
    api_module.store = TransactionStore(path=str(tmp_path / "txs.json"))
    flask_app.config["TESTING"] = True
    with flask_app.test_client() as c:
        yield c


def post_tx(client, amount=50.0, tx_type="expense", category="food"):
    return client.post("/transactions",
                        data=json.dumps({"amount": amount, "type": tx_type,
                                          "category": category}),
                        content_type="application/json")


def test_create_transaction(client):
    r = post_tx(client)
    assert r.status_code == 201
    data = json.loads(r.data)
    assert data["amount"] == 50.0


def test_list_transactions(client):
    post_tx(client)
    post_tx(client, tx_type="income", category="salary")
    r = client.get("/transactions")
    assert len(json.loads(r.data)) == 2


def test_filter_by_type(client):
    post_tx(client, tx_type="expense")
    post_tx(client, tx_type="income", category="salary")
    r = client.get("/transactions?type=expense")
    assert all(t["type"] == "expense" for t in json.loads(r.data))


def test_delete_transaction(client):
    r = post_tx(client)
    tx_id = json.loads(r.data)["id"]
    r2 = client.delete(f"/transactions/{tx_id}")
    assert r2.status_code == 200


def test_get_missing_transaction(client):
    r = client.get("/transactions/nonexistent")
    assert r.status_code == 404


def test_summary(client):
    post_tx(client, amount=1000, tx_type="income", category="salary")
    post_tx(client, amount=200)
    r = client.get("/summary")
    data = json.loads(r.data)
    assert data["net_balance"] == 800.0
