"""Tests for input validators."""
from app.validators import validate_transaction


def test_valid_payload():
    ok, errors = validate_transaction({"amount": 50.0, "type": "expense"})
    assert ok
    assert errors == []


def test_missing_amount():
    ok, errors = validate_transaction({"type": "expense"})
    assert not ok
    assert any("amount" in e for e in errors)


def test_invalid_amount():
    ok, errors = validate_transaction({"amount": "abc", "type": "expense"})
    assert not ok


def test_negative_amount():
    ok, errors = validate_transaction({"amount": -10, "type": "expense"})
    assert not ok


def test_invalid_type():
    ok, errors = validate_transaction({"amount": 10, "type": "transfer"})
    assert not ok
