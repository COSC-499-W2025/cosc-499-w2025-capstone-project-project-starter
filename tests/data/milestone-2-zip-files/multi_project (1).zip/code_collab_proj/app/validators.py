"""Input validation helpers."""
from typing import Any, Dict, List, Tuple


def validate_transaction(data: Dict[str, Any]) -> Tuple[bool, List[str]]:
    errors = []
    if "amount" not in data:
        errors.append("amount is required")
    else:
        try:
            amount = float(data["amount"])
            if amount <= 0:
                errors.append("amount must be positive")
        except (ValueError, TypeError):
            errors.append("amount must be a number")

    if "type" not in data:
        errors.append("type is required")
    elif data["type"] not in ("income", "expense"):
        errors.append("type must be income or expense")

    return len(errors) == 0, errors
