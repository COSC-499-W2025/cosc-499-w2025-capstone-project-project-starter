"""Budget analytics and summaries."""
from collections import defaultdict
from typing import Dict, List, Tuple
from app.models import Category, Transaction, TransactionType


def total_income(txs: List[Transaction]) -> float:
    return sum(t.amount for t in txs if t.type == TransactionType.INCOME)


def total_expenses(txs: List[Transaction]) -> float:
    return sum(t.amount for t in txs if t.type == TransactionType.EXPENSE)


def net_balance(txs: List[Transaction]) -> float:
    return total_income(txs) - total_expenses(txs)


def by_category(txs: List[Transaction]) -> Dict[str, float]:
    totals: Dict[str, float] = defaultdict(float)
    for t in txs:
        if t.type == TransactionType.EXPENSE:
            totals[t.category.value] += t.amount
    return dict(totals)


def monthly_summary(txs: List[Transaction]) -> Dict[str, dict]:
    months: Dict[str, List[Transaction]] = defaultdict(list)
    for t in txs:
        key = t.date.strftime("%Y-%m")
        months[key].append(t)
    return {
        month: {
            "income": total_income(ts),
            "expenses": total_expenses(ts),
            "net": net_balance(ts),
            "count": len(ts),
        }
        for month, ts in sorted(months.items())
    }


def top_expense_categories(txs: List[Transaction], n: int = 5) -> List[Tuple[str, float]]:
    cats = by_category(txs)
    return sorted(cats.items(), key=lambda x: x[1], reverse=True)[:n]


def over_budget(txs: List[Transaction], limits: Dict[str, float]) -> Dict[str, float]:
    spent = by_category(txs)
    return {
        cat: spent[cat] - limit
        for cat, limit in limits.items()
        if spent.get(cat, 0) > limit
    }
