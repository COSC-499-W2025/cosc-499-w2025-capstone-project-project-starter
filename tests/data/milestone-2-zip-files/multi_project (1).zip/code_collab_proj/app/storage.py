"""JSON-based storage for transactions and budgets."""
import json
import shutil
from pathlib import Path
from typing import List, Optional
from app.models import Transaction


class TransactionStore:
    def __init__(self, path: str = "data/transactions.json"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text("[]")

    def _read(self) -> List[dict]:
        return json.loads(self.path.read_text())

    def _write(self, data: List[dict]):
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2))
        shutil.move(str(tmp), str(self.path))

    def all(self) -> List[Transaction]:
        return [Transaction.from_dict(d) for d in self._read()]

    def get(self, tx_id: str) -> Optional[Transaction]:
        for d in self._read():
            if d["id"] == tx_id:
                return Transaction.from_dict(d)
        return None

    def save(self, tx: Transaction):
        data = self._read()
        for i, d in enumerate(data):
            if d["id"] == tx.id:
                data[i] = tx.to_dict()
                self._write(data)
                return
        data.append(tx.to_dict())
        self._write(data)

    def delete(self, tx_id: str) -> bool:
        data = self._read()
        new = [d for d in data if d["id"] != tx_id]
        if len(new) == len(data):
            return False
        self._write(new)
        return True

    def count(self) -> int:
        return len(self._read())
