"""Flask REST API for budget tracker."""
from flask import Flask, jsonify, request
from app.analytics import by_category, monthly_summary, net_balance, over_budget
from app.models import Category, Transaction, TransactionType
from app.storage import TransactionStore

app = Flask(__name__)
store = TransactionStore()


@app.route("/transactions", methods=["GET"])
def list_transactions():
    txs = store.all()
    type_filter = request.args.get("type")
    if type_filter:
        txs = [t for t in txs if t.type.value == type_filter]
    return jsonify([t.to_dict() for t in txs])


@app.route("/transactions", methods=["POST"])
def create_transaction():
    data = request.get_json()
    if not data:
        return jsonify({"error": "No data"}), 400
    try:
        tx = Transaction(
            amount=float(data["amount"]),
            type=TransactionType(data["type"]),
            category=Category(data.get("category", "other")),
            description=data.get("description", ""),
            tags=data.get("tags", []),
        )
        store.save(tx)
        return jsonify(tx.to_dict()), 201
    except (KeyError, ValueError) as e:
        return jsonify({"error": str(e)}), 400


@app.route("/transactions/<tx_id>", methods=["GET"])
def get_transaction(tx_id):
    tx = store.get(tx_id)
    if not tx:
        return jsonify({"error": "Not found"}), 404
    return jsonify(tx.to_dict())


@app.route("/transactions/<tx_id>", methods=["DELETE"])
def delete_transaction(tx_id):
    if store.delete(tx_id):
        return jsonify({"deleted": tx_id})
    return jsonify({"error": "Not found"}), 404


@app.route("/summary", methods=["GET"])
def summary():
    txs = store.all()
    return jsonify({
        "net_balance": net_balance(txs),
        "by_category": by_category(txs),
        "monthly": monthly_summary(txs),
    })


@app.route("/budget/check", methods=["POST"])
def check_budget():
    data = request.get_json() or {}
    limits = data.get("limits", {})
    txs = store.all()
    overages = over_budget(txs, limits)
    return jsonify({"over_budget": overages})
