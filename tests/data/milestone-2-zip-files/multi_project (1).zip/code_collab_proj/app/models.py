"""Domain models for budget tracking."""
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import List, Optional
import uuid


class TransactionType(Enum):
    INCOME = "income"
    EXPENSE = "expense"


class Category(Enum):
    FOOD = "food"
    TRANSPORT = "transport"
    HOUSING = "housing"
    ENTERTAINMENT = "entertainment"
    HEALTH = "health"
    UTILITIES = "utilities"
    SALARY = "salary"
    OTHER = "other"


@dataclass
class Transaction:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    amount: float = 0.0
    type: TransactionType = TransactionType.EXPENSE
    category: Category = Category.OTHER
    description: str = ""
    date: datetime = field(default_factory=datetime.utcnow)
    tags: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "amount": self.amount,
            "type": self.type.value,
            "category": self.category.value,
            "description": self.description,
            "date": self.date.isoformat(),
            "tags": self.tags,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Transaction":
        return cls(
            id=d["id"],
            amount=float(d["amount"]),
            type=TransactionType(d["type"]),
            category=Category(d["category"]),
            description=d.get("description", ""),
            date=datetime.fromisoformat(d["date"]),
            tags=d.get("tags", []),
        )


@dataclass
class Budget:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    month: str = ""  # YYYY-MM
    limits: dict = field(default_factory=dict)  # category -> float
    created_at: datetime = field(default_factory=datetime.utcnow)
