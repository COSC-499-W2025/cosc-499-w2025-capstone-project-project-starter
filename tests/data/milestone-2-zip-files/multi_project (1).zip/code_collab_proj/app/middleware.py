"""Request middleware and helpers."""
import functools
import time
from flask import g, request


def log_requests(app):
    @app.before_request
    def start_timer():
        g.start = time.monotonic()

    @app.after_request
    def log_response(response):
        elapsed = time.monotonic() - g.start
        app.logger.info(
            "%s %s %s %.3fs",
            request.method, request.path,
            response.status_code, elapsed
        )
        return response
    return app


def require_json(f):
    @functools.wraps(f)
    def decorated(*args, **kwargs):
        if request.method in ("POST", "PUT", "PATCH"):
            if not request.is_json:
                from flask import jsonify
                return jsonify({"error": "Content-Type must be application/json"}), 415
        return f(*args, **kwargs)
    return decorated
