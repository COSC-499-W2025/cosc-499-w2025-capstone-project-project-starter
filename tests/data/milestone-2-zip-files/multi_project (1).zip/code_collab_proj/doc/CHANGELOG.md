# Changelog

## v0.1.0 — 2024-02-01
- Initial release: models, storage, analytics (Sam Rivera)

## v0.2.0 — 2024-02-08
- REST API with Flask (Morgan Chen)
- Middleware logging and request validation

## v0.3.0 — 2024-02-15
- Full test suite with 95%+ coverage (Taylor Brooks)
- API spec and contributor docs
