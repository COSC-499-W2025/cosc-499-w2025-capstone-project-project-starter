# Budget Tracker API

A collaborative REST API for personal budget tracking.

## Team

- **Sam Rivera** — core models, storage, analytics
- **Morgan Chen** — Flask REST API, middleware, validators
- **Taylor Brooks** — testing, documentation, CI

## Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | /transactions | List all transactions |
| POST | /transactions | Create a transaction |
| GET | /transactions/:id | Get one transaction |
| DELETE | /transactions/:id | Delete a transaction |
| GET | /summary | Analytics summary |
| POST | /budget/check | Check against budget limits |

## Running

```bash
pip install -r requirements.txt
flask --app app.api run
```

## Testing

```bash
pytest --cov=app
```
