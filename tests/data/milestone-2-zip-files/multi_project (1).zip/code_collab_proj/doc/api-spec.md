# API Specification

## Transaction Object

```json
{
  "id": "uuid",
  "amount": 50.0,
  "type": "expense",
  "category": "food",
  "description": "Lunch",
  "date": "2024-02-01T12:00:00",
  "tags": ["work"]
}
```

## Categories

`food`, `transport`, `housing`, `entertainment`, `health`, `utilities`, `salary`, `other`

## Error Responses

All errors return `{"error": "message"}` with an appropriate HTTP status code.
