# Benchmark Specification

## Workload Parameters

| Parameter | Value |
|-----------|-------|
| Key space size | 10,000 keys |
| Value size | 256 bytes (uniform) |
| Read/write ratio | 80% reads, 20% writes |
| Concurrency | 10, 50, 100 clients |
| Duration | 60 seconds per run |
| Warm-up | 10 seconds (excluded from results) |

## Metrics Collected

- **Throughput** (ops/sec)
- **P50, P95, P99 latency** (ms)
- **Hit rate** (%)
- **Memory utilisation** (MB)
- **CPU usage** (%)

## Environments

All tests run on Docker containers on the same host to eliminate
network variance.

```yaml
redis:
  image: redis:7.2
  command: redis-server --maxmemory 256mb --maxmemory-policy allkeys-lru

memcached:
  image: memcached:1.6
  command: memcached -m 256 -c 1024
```

## Invalidation Tests

For event-driven invalidation, a separate writer process updates
keys at a configurable rate. Staleness is measured as the fraction
of reads returning an outdated value.
