# Annotated Bibliography

## Primary Sources

**Nishtala et al. (2013). Scaling Memcache at Facebook.**
Describes how Facebook evolved Memcached deployments to serve billions
of requests per second. Key contributions: lease mechanism to address
stale sets and thundering herd; regional pools for cold-start; gutter
servers for failure resilience.

*Relevance*: Demonstrates real-world invalidation challenges at scale.
The lease mechanism directly informs our event-driven invalidation design.

---

**Redis Cluster Specification (Sanfilippo, 2015).**
Official specification for Redis Cluster, covering hash slot partitioning,
gossip-based failure detection, and automatic resharding.

*Relevance*: Basis for understanding Redis horizontal scaling behaviour
and failure modes tested in Section 4 of this study.

---

**DeCandia et al. (2007). Dynamo: Amazon's Highly Available Key-value Store.**
Foundational paper on eventual consistency, vector clocks, and sloppy
quorums. While Dynamo is not a cache, its consistency models directly
apply to distributed cache design.

*Relevance*: Provides theoretical grounding for consistency trade-off
analysis in the conclusion.
