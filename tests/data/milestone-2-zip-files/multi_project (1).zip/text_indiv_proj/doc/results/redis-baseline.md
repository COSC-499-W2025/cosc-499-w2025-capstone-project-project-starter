# Redis Baseline Results

## Environment
- Redis 7.2, 256MB max memory, allkeys-lru eviction
- 10 concurrent clients, 60s run

## Throughput

| Load Level | Reads (ops/s) | Writes (ops/s) |
|------------|---------------|----------------|
| Low (10c)  | 48,200        | 12,100         |
| Med (50c)  | 89,400        | 22,300         |
| High (100c)| 94,100        | 23,500         |

## Latency (ms)

| Load Level | P50  | P95  | P99  |
|------------|------|------|------|
| Low        | 0.21 | 0.48 | 0.92 |
| Med        | 0.44 | 1.12 | 2.31 |
| High       | 0.61 | 2.87 | 8.14 |

## Hit Rate
- Warm cache (after 10s): **87.3%**
- Steady state: **85.1%** at TTL=60s

## Observations
- Throughput plateaus around 50 clients due to single-threaded
  command processing
- P99 latency spikes significantly at 100 clients
