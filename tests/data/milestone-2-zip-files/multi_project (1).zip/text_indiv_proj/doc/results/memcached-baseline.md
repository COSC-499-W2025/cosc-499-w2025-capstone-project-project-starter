# Memcached Baseline Results

## Environment
- Memcached 1.6, 256MB, LRU eviction
- Connection pool size: 20 per client

## Throughput

| Load Level | Reads (ops/s) | Writes (ops/s) |
|------------|---------------|----------------|
| Low (10c)  | 62,400        | 15,700         |
| Med (50c)  | 134,200       | 33,600         |
| High (100c)| 178,900       | 44,700         |

## Latency (ms)

| Load Level | P50  | P95  | P99  |
|------------|------|------|------|
| Low        | 0.16 | 0.31 | 0.58 |
| Med        | 0.29 | 0.71 | 1.44 |
| High       | 0.38 | 1.02 | 2.89 |

## Hit Rate
- Warm cache: **88.9%**
- Steady state: **86.4%** at TTL=60s

## Observations
- Multi-threaded architecture allows near-linear throughput scaling
- Lower per-key memory overhead (~40 bytes vs ~90 bytes for Redis)
- Simpler behaviour under load, no P99 spikes seen at 100 clients
