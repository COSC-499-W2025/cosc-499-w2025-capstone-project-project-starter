# Conclusion

This study compared Redis and Memcached across throughput, latency, hit rate,
and cache invalidation strategies.

## Key Findings

- Memcached provides superior raw throughput (~90% higher at 100 clients)
  and more predictable tail latency
- Redis offers a far richer feature set enabling sophisticated caching
  patterns not possible with Memcached
- TTL-based invalidation is simple but may serve stale data for up to
  TTL seconds; event-driven invalidation achieves near-real-time consistency
  at the cost of added complexity
- Hit rates are comparable between systems given equivalent memory budgets

## Limitations

- Tests conducted on a single host; network latency not measured
- Benchmark workload (uniform 256-byte values) may not represent
  production distributions
- Redis 7.2 multi-threaded I/O was not explicitly tested

## Future Work

- Extend benchmarks to cluster configurations (Redis Cluster,
  Memcached with consistent hashing)
- Investigate cache warming strategies for cold-start scenarios
- Evaluate newer Redis alternatives (KeyDB, Dragonfly)
