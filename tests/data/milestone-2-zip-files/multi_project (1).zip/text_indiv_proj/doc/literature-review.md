# Literature Review: Distributed Caching

## 1. Foundations

### 1.1 Cache Basics
A cache is a fast, temporary data store that holds copies of frequently
accessed data to reduce the cost of repeated computations or lookups.

Key properties:
- **Hit rate**: fraction of requests served from cache
- **Eviction policy**: how stale or excess data is removed (LRU, LFU, FIFO)
- **TTL (Time-to-Live)**: maximum age of a cached entry

### 1.2 Distributed vs Local Caches
Local (in-process) caches offer the lowest latency but cannot be shared
across service instances. Distributed caches trade some latency for
consistency across horizontally scaled services.

## 2. Key Technologies

### 2.1 Redis
Redis is an in-memory data structure store supporting strings, hashes,
lists, sets, and sorted sets. It supports persistence via RDB snapshots
and AOF logging. Redis Cluster provides horizontal partitioning and
automatic failover.

Strengths:
- Rich data structures enable sophisticated caching patterns
- Pub/Sub support for event-driven invalidation
- Lua scripting for atomic multi-key operations

Limitations:
- Single-threaded command execution (pre-v6)
- Memory-bound capacity

### 2.2 Memcached
Memcached is a simpler, multi-threaded in-memory key-value store.
It is designed purely for caching and offers no persistence.

Strengths:
- Extremely high throughput for simple get/set workloads
- Lower memory overhead per key
- Linear horizontal scaling

Limitations:
- No persistence or replication built-in
- Limited data types (strings only)

## 3. Cache Invalidation Strategies

### 3.1 TTL-Based Invalidation
Each cache entry expires after a fixed duration. Simple to implement,
but may serve stale data up to TTL seconds after the underlying data changes.

### 3.2 Event-Driven Invalidation
The data layer publishes change events; cache subscribers evict affected
keys immediately. Achieves near-perfect consistency but adds operational
complexity.

### 3.3 Write-Through and Write-Behind
Write-through caches update both cache and backing store synchronously.
Write-behind (write-back) updates only the cache and asynchronously
flushes to the store, trading consistency for write throughput.

## 4. Consistency Models

- **Strong consistency**: reads always return the latest write
- **Eventual consistency**: reads eventually converge to the latest write
- **Read-your-writes**: a client always sees its own writes

Most distributed caches offer eventual consistency by default.
