# Analysis and Discussion

## 1. Throughput Comparison

Memcached outperforms Redis by approximately **90%** at high concurrency
for simple get/set workloads. This is expected given Memcached's
multi-threaded architecture vs Redis's single-threaded model (pre-v6).

For workloads requiring complex data structures (sorted sets, pub/sub),
Redis becomes the clear choice as Memcached cannot support them natively.

## 2. Latency

Both systems achieve sub-millisecond P50 and P95 latency at moderate load.
Redis P99 latency degrades more sharply at high concurrency (8.14ms vs
2.89ms for Memcached at 100 clients). Applications with strict tail latency
requirements should consider this carefully.

## 3. Hit Rates

Hit rates were comparable (~85-88%) under similar TTL and key space
configurations. The marginal Memcached advantage likely reflects its
lower per-key overhead allowing more keys to fit in the same memory budget.

## 4. Invalidation Strategy Comparison

| Strategy | Consistency | Complexity | Suitable For |
|----------|-------------|------------|--------------|
| TTL-only | Eventual | Low | Tolerant reads |
| Event-driven | Strong | High | Financial, inventory |
| Write-through | Strong | Medium | Write-heavy systems |

Event-driven invalidation added ~2ms of write latency due to pub/sub
overhead but reduced maximum staleness from TTL seconds to <50ms.

## 5. Recommendations

1. **Use Memcached** for high-throughput, simple caching where Redis
   features are not needed and tail latency is critical.
2. **Use Redis** when you need data structures, persistence, Lua scripting,
   or event-driven invalidation via Pub/Sub.
3. **Prefer event-driven invalidation** for consistency-sensitive data
   despite the added complexity.
4. **Always measure hit rate** in production — a low hit rate negates
   caching benefits entirely.
