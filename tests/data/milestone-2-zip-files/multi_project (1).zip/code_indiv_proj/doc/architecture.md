# Architecture

## Components

- **fetcher** — raw HTTP, error wrapping
- **parser** — regex-based HTML extraction  
- **crawler** — BFS queue, domain filtering
- **pipeline** — orchestrates fetch → parse → store
- **rate_limiter** — polite crawl delay
- **robots** — respects robots.txt
- **storage** — JSON output persistence
