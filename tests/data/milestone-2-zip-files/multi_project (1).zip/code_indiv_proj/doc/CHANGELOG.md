# Changelog

## v0.1.0
- Initial release: fetcher, parser, storage

## v0.2.0
- Add BFS crawler with domain filtering
- Add rate limiter and robots.txt support
- Full test suite with mocks
