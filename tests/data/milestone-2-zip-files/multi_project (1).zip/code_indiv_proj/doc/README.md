# Web Scraper

A lightweight personal web scraping toolkit.

## Modules

- `fetcher.py` — HTTP fetch with error handling
- `parser.py` — HTML title, link, text, meta extraction
- `crawler.py` — single-domain BFS crawler
- `pipeline.py` — high-level scrape pipeline
- `storage.py` — JSON result persistence

## Usage

```python
from app.pipeline import run_pipeline
results = run_pipeline("https://example.com", max_pages=10)
print(results["stats"])
```

## Testing

```bash
pytest
```
