"""Tests for rate limiter."""
import time
from app.rate_limiter import RateLimiter


def test_rate_limiter_delays():
    rl = RateLimiter(requests_per_second=100)  # fast for tests
    rl.wait()
    start = time.monotonic()
    rl.wait()
    elapsed = time.monotonic() - start
    assert elapsed < 1.0  # just verify it runs without error
