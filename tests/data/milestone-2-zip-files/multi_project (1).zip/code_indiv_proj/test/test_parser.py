"""Tests for HTML parser."""
import pytest
from app.parser import extract_links, extract_meta, extract_text, parse_title


def test_parse_title():
    assert parse_title("<title>Hello</title>") == "Hello"

def test_parse_title_missing():
    assert parse_title("<html></html>") is None

def test_parse_title_whitespace():
    assert parse_title("<title>  Trimmed  </title>") == "Trimmed"

def test_extract_links_absolute():
    html = '<a href="https://example.com/page">link</a>'
    assert "https://example.com/page" in extract_links(html)

def test_extract_links_relative():
    html = '<a href="/about">About</a>'
    links = extract_links(html, base_url="https://example.com")
    assert "https://example.com/about" in links

def test_extract_links_skips_anchors():
    html = '<a href="#section">Jump</a>'
    assert extract_links(html) == []

def test_extract_text_strips_tags():
    html = "<p>Hello <b>world</b></p>"
    assert "Hello" in extract_text(html)
    assert "<b>" not in extract_text(html)

def test_extract_text_strips_scripts():
    html = "<script>alert(1)</script><p>Content</p>"
    text = extract_text(html)
    assert "alert" not in text
    assert "Content" in text

def test_extract_meta():
    html = '<meta name="description" content="A test page">'
    assert extract_meta(html, "description") == "A test page"

def test_extract_meta_missing():
    assert extract_meta("<html></html>", "description") is None
