"""Tests for crawler (with mocked fetch)."""
from unittest.mock import patch
from app.crawler import Crawler


MOCK_HTML = '<html><title>Test</title><a href="https://example.com/page2">link</a></html>'


def test_crawl_visits_start():
    pages = {}
    with patch("app.crawler.fetch", return_value=MOCK_HTML):
        c = Crawler("https://example.com", max_pages=2)
        c.crawl(on_page=lambda url, html: pages.update({url: html}))
    assert "https://example.com" in pages


def test_stats_after_crawl():
    with patch("app.crawler.fetch", return_value=MOCK_HTML):
        c = Crawler("https://example.com", max_pages=1)
        c.crawl()
    assert c.stats["visited"] >= 1
