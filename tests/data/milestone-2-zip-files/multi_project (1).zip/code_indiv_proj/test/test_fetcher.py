"""Tests for fetcher (uses mocking)."""
import pytest
from unittest.mock import MagicMock, patch
from app.fetcher import FetchError, fetch


def test_fetch_success():
    mock_response = MagicMock()
    mock_response.read.return_value = b"<html>content</html>"
    mock_response.__enter__ = lambda s: s
    mock_response.__exit__ = MagicMock(return_value=False)
    with patch("urllib.request.urlopen", return_value=mock_response):
        result = fetch("https://example.com")
    assert "content" in result


def test_fetch_http_error():
    import urllib.error
    with patch("urllib.request.urlopen", side_effect=urllib.error.HTTPError(
        "https://example.com", 404, "Not Found", {}, None
    )):
        with pytest.raises(FetchError):
            fetch("https://example.com")
