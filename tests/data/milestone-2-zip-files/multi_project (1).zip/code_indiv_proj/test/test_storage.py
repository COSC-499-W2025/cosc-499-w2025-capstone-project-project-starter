"""Tests for result store."""
import pytest
from app.storage import ResultStore


@pytest.fixture
def store(tmp_path):
    return ResultStore(output_dir=str(tmp_path / "output"))


def test_save_and_load(store):
    store.save("test", {"key": "value"})
    result = store.load("test")
    assert result["key"] == "value"

def test_load_missing(store):
    with pytest.raises(FileNotFoundError):
        store.load("nonexistent")

def test_list_results(store):
    store.save("a", {})
    store.save("b", {})
    assert sorted(store.list_results()) == ["a", "b"]
