"""HTTP fetching utilities."""
import urllib.request
import urllib.error
from typing import Optional


class FetchError(Exception):
    pass


def fetch(url: str, timeout: int = 10) -> str:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            return r.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as e:
        raise FetchError(f"HTTP {e.code}: {url}") from e
    except urllib.error.URLError as e:
        raise FetchError(f"URL error: {e.reason}") from e


def fetch_bytes(url: str, timeout: int = 10) -> bytes:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            return r.read()
    except Exception as e:
        raise FetchError(str(e)) from e
