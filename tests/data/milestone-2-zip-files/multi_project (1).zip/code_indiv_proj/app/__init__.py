"""Web scraper package."""
