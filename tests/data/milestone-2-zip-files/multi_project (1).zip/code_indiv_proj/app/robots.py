"""robots.txt parsing to respect crawl rules."""
import urllib.request
from typing import Set


class RobotsTxt:
    def __init__(self):
        self.disallowed: Set[str] = set()

    @classmethod
    def fetch(cls, base_url: str) -> "RobotsTxt":
        obj = cls()
        try:
            robots_url = base_url.rstrip("/") + "/robots.txt"
            with urllib.request.urlopen(robots_url, timeout=5) as r:
                for line in r.read().decode().splitlines():
                    if line.lower().startswith("disallow:"):
                        path = line.split(":", 1)[1].strip()
                        if path:
                            obj.disallowed.add(path)
        except Exception:
            pass
        return obj

    def is_allowed(self, path: str) -> bool:
        for d in self.disallowed:
            if path.startswith(d):
                return False
        return True
