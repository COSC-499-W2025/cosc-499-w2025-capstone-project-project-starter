"""Save scraped results to disk."""
import json
from pathlib import Path
from typing import Any, Dict, List


class ResultStore:
    def __init__(self, output_dir: str = "output"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def save(self, name: str, data: Any):
        path = self.output_dir / f"{name}.json"
        path.write_text(json.dumps(data, indent=2))

    def load(self, name: str) -> Any:
        path = self.output_dir / f"{name}.json"
        if not path.exists():
            raise FileNotFoundError(f"No result: {name}")
        return json.loads(path.read_text())

    def list_results(self) -> List[str]:
        return [p.stem for p in sorted(self.output_dir.glob("*.json"))]
