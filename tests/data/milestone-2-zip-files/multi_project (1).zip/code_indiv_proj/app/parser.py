"""HTML parsing utilities."""
import re
from typing import List, Optional


def parse_title(html: str) -> Optional[str]:
    match = re.search(r"<title[^>]*>(.*?)</title>", html, re.IGNORECASE | re.DOTALL)
    return match.group(1).strip() if match else None


def extract_links(html: str, base_url: str = "") -> List[str]:
    raw = re.findall(r'href=["\']([^"\']+)["\']', html, re.IGNORECASE)
    links = []
    for link in raw:
        link = link.strip()
        if not link or link.startswith("#") or link.startswith("javascript:"):
            continue
        if link.startswith("http"):
            links.append(link)
        elif base_url and link.startswith("/"):
            links.append(base_url.rstrip("/") + link)
    return links


def extract_text(html: str) -> str:
    text = re.sub(r"<script[^>]*>.*?</script>", "", html, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<style[^>]*>.*?</style>", "", text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def extract_meta(html: str, name: str) -> Optional[str]:
    pattern = rf'<meta[^>]+name=["\']?{re.escape(name)}["\']?[^>]+content=["\']([^"\']+)["\']'
    match = re.search(pattern, html, re.IGNORECASE)
    return match.group(1) if match else None
