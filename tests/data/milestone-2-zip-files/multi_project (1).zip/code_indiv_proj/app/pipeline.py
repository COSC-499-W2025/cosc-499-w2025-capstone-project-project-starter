"""Scrape pipeline combining fetch, parse, store."""
from app.crawler import Crawler
from app.fetcher import fetch, FetchError
from app.parser import extract_links, extract_text, parse_title
from app.storage import ResultStore


def scrape_page(url: str, store: ResultStore) -> dict:
    html = fetch(url)
    result = {
        "url": url,
        "title": parse_title(html),
        "links": extract_links(html, url),
        "text_snippet": extract_text(html)[:500],
    }
    slug = url.replace("https://", "").replace("http://", "").replace("/", "_")[:60]
    store.save(slug, result)
    return result


def run_pipeline(start_url: str, max_pages: int = 20) -> dict:
    store = ResultStore()
    results = []

    def on_page(url, html):
        result = {
            "url": url,
            "title": parse_title(html),
            "link_count": len(extract_links(html)),
        }
        results.append(result)

    crawler = Crawler(start_url, max_pages=max_pages)
    crawler.crawl(on_page=on_page)
    store.save("crawl_summary", {"start": start_url, "pages": results})
    return {"pages": results, "stats": crawler.stats}
