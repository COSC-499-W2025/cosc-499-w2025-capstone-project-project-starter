"""Simple single-domain crawler."""
from collections import deque
from typing import Callable, Optional, Set
from app.fetcher import fetch, FetchError
from app.parser import extract_links


class Crawler:
    def __init__(self, base_url: str, max_pages: int = 50):
        self.base_url = base_url.rstrip("/")
        self.max_pages = max_pages
        self.visited: Set[str] = set()
        self.errors: dict = {}

    def _same_domain(self, url: str) -> bool:
        return url.startswith(self.base_url)

    def crawl(self, on_page: Optional[Callable[[str, str], None]] = None):
        queue = deque([self.base_url])
        while queue and len(self.visited) < self.max_pages:
            url = queue.popleft()
            if url in self.visited:
                continue
            self.visited.add(url)
            try:
                html = fetch(url)
                if on_page:
                    on_page(url, html)
                for link in extract_links(html, self.base_url):
                    if self._same_domain(link) and link not in self.visited:
                        queue.append(link)
            except FetchError as e:
                self.errors[url] = str(e)

    @property
    def stats(self) -> dict:
        return {
            "visited": len(self.visited),
            "errors": len(self.errors),
            "max_pages": self.max_pages,
        }
