Collaborative project notes.
