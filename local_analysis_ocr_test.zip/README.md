# Solar Yield Predictor

This project predicts solar energy yield using time-series data.
Focus areas: forecasting, regression, evaluation metrics.
